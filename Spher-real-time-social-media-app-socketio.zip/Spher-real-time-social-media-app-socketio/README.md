# MERN-APP-beta

![diary posts](/frontend/public/4.png "posts")  


![diary posts](/frontend/public/3.PNG "posts")  
![diary posts](/frontend/public/5.PNG "posts")  
